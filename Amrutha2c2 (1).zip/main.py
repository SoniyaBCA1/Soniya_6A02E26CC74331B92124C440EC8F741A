students = [
    {
        "name": "Alice",
        "roll number": "A123",
        "CGPA": 3.8
    },
    {
        "name": "Bob",
        "roll number": "B456",
        "CGPA": 3.5
    },
    {
        "name": "Charlie",
        "roll number": "C789",
        "CGPA": 4.0
    },
    {
        "name": "David",
        "roll number": "D101",
        "CGPA": 3.9
    },
]

sorted_students = sort_students(students)
for student in sorted_students:
  print(
      f"Name: {student['name']}, Roll Number: {student['roll number']}, CGPA: {student['CGPA']}"
  )
